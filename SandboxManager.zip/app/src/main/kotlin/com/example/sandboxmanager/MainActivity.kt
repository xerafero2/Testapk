package com.example.sandboxmanager

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import java.io.File
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private val stagedDir by lazy { File(filesDir, "staged_apks").apply { mkdirs() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        refresh()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 24)
        }

        val title = TextView(this).apply {
            text = "Sandbox Manager"
            textSize = 25f
            setTextColor(0xFF111827.toInt())
        }
        root.addView(title, lp())

        val subtitle = TextView(this).apply {
            text = "APK staging & instance manager (MVP)"
            textSize = 14f
            setTextColor(0xFF6B7280.toInt())
            setPadding(0, 6, 0, 18)
        }
        root.addView(subtitle, lp())

        val warning = TextView(this).apply {
            text = "⚠ APK yang diimpor hanya disimpan di storage privat aplikasi. MVP ini TIDAK menjalankan APK. Isolasi eksekusi memerlukan virtual machine/container backend."
            textSize = 14f
            setTextColor(0xFF92400E.toInt())
            setBackgroundColor(0xFFFFF7ED.toInt())
            setPadding(18, 16, 18, 16)
        }
        root.addView(warning, lp())

        val importButton = Button(this).apply {
            text = "＋  Import APK"
            setOnClickListener { chooseApk() }
        }
        val bLp = lp()
        bLp.topMargin = 18
        root.addView(importButton, bLp)

        status = TextView(this).apply {
            textSize = 13f
            setTextColor(0xFF4B5563.toInt())
            setPadding(0, 16, 0, 8)
        }
        root.addView(status, lp())

        val scroll = ScrollView(this)
        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
    }

    private fun chooseApk() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "application/vnd.android.package-archive"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(intent, REQUEST_APK)
    }

    @Deprecated("Activity Result API is unnecessary for this minimal dependency-free MVP.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_APK || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            importApk(uri)
            refresh()
        } catch (e: Exception) {
            Toast.makeText(this, "Import gagal: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun importApk(uri: Uri) {
        val resolver = contentResolver
        val original = queryDisplayName(uri) ?: "unknown.apk"
        val safeName = original.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val destination = uniqueFile(File(stagedDir, safeName))

        resolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Tidak dapat membaca APK." }
            destination.outputStream().use { output -> input.copyTo(output) }
        }

        val hash = sha256(destination)
        File(destination.absolutePath + ".sha256").writeText(hash)
        Toast.makeText(this, "APK disimpan. SHA-256: ${hash.take(16)}…", Toast.LENGTH_LONG).show()
    }

    private fun queryDisplayName(uri: Uri): String? {
        contentResolver.query(uri, arrayOf("_display_name"), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0)
        }
        return null
    }

    private fun uniqueFile(file: File): File {
        if (!file.exists()) return file
        val base = file.nameWithoutExtension
        val ext = file.extension
        var n = 2
        while (true) {
            val candidate = File(file.parentFile, "$base-$n.$ext")
            if (!candidate.exists()) return candidate
            n++
        }
    }

    private fun sha256(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count <= 0) break
                md.update(buffer, 0, count)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun refresh() {
        list.removeAllViews()
        val apks = stagedDir.listFiles()
            ?.filter { it.isFile && it.extension.equals("apk", true) }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()

        status.text = "${apks.size} APK tersimpan di sandbox privat."

        if (apks.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "Belum ada APK.\nGunakan Import APK untuk memasukkannya ke staging area."
                textSize = 16f
                setTextColor(0xFF6B7280.toInt())
                setPadding(0, 24, 0, 24)
            }, lp())
            return
        }

        for (apk in apks) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(20, 18, 20, 18)
                setBackgroundColor(0xFFF3F4F6.toInt())
            }

            val name = TextView(this).apply {
                text = apk.name
                textSize = 17f
                setTextColor(0xFF111827.toInt())
            }
            card.addView(name, lp())

            val info = TextView(this).apply {
                val time = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(apk.lastModified()))
                text = "Size: ${apk.length() / 1024} KB\nImported: $time"
                textSize = 13f
                setTextColor(0xFF6B7280.toInt())
                setPadding(0, 6, 0, 8)
            }
            card.addView(info, lp())

            val actions = LinearLayout(this).apply { gravity = Gravity.END }
            val hashBtn = Button(this).apply {
                text = "SHA-256"
                setOnClickListener {
                    Toast.makeText(this@MainActivity, sha256(apk), Toast.LENGTH_LONG).show()
                }
            }
            val deleteBtn = Button(this).apply {
                text = "Hapus"
                setOnClickListener {
                    apk.delete()
                    File(apk.absolutePath + ".sha256").delete()
                    refresh()
                }
            }
            actions.addView(hashBtn)
            actions.addView(deleteBtn)
            card.addView(actions, lp())

            val outer = LinearLayout.LayoutParams(-1, -2).apply {
                bottomMargin = 14
            }
            list.addView(card, outer)
        }
    }

    private fun lp() = LinearLayout.LayoutParams(-1, -2)

    companion object {
        private const val REQUEST_APK = 1001
    }
}
